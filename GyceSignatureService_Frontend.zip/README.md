# Gyce Signature Service Website
Full website package for Gyce Signature Service in Arkansas.
## Features
- Home, Services, About, Contact, Book Notarization pages
- Online booking with document upload
- Responsive design and PHP backend
## Hosting
- PHP server required for form submissions
- Upload folder must have write permissions
- Update $recipient in submit_booking.php
